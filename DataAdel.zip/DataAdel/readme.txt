bikeshare project from Udacity
learn from:
Udacity course
Python.org
pandas.pydata.org
Pythontic.com
stackoverflow.com